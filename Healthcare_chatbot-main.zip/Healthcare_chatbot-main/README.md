# Healthcare_chatbot
It is a healthcare chatbot developed using rasa framework.
command to run the rasa server
rasa run --enable-api --cors '*' -p 1001
